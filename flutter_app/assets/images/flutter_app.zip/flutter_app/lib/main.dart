import 'package:flutter/material.dart';
import 'package:flutter_app/screens/intro_screen.dart';
import 'package:flutter_app/screens/leaderboard_screen.dart';
import 'package:flutter_app/screens/profile_screen.dart';
import 'package:flutter_app/screens/videocam_screen.dart';
import 'package:flutter_app/screens/settings_screen.dart';
import 'package:flutter_app/config/mysqlconnect.dart';
import 'package:flutter_app/loginPage/loginMainPage.dart';
import 'package:flutter_app/weather/weather_screen.dart';
import 'package:flutter_app/splash.main.dart'; // 추가

void main() {
  dbConnector();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    //if (snapshot.connectionState == ConnectionState.done) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      routes: {
        '/splash': (context) => SplashScreen(), // 추가
        '/home': (context) => IntroScreen(),
        '/leaderboard': (context) => LeaderboardScreen(),
        '/videocam': (context) => VideocamScreen(),
        '/settings': (context) => SettingsScreen(),
        '/login': (context) => TokenCheck(),
        '/profile': (context) => ProfileScreen(),
        '/weather': (context) => WeatherScreen(),
      },
      initialRoute: '/splash', // 변경
    );
    //} else {
    //return CircularProgressIndicator(); // 연결이 완료될 때까지 로딩 표시
    // }
  }
}
