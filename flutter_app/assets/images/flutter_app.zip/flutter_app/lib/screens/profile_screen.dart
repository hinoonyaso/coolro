import 'package:flutter/material.dart';
import 'package:flutter_app/shared/menu_drawer.dart';
import 'package:flutter_app/shared/menu_bottom.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Profile'), backgroundColor: Colors.cyan),
      drawer: MenuDrawer(),
      body: Center(),
      backgroundColor: Colors.white,
      bottomNavigationBar: MenuBottom(),
    );
  }
}
