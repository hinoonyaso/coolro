import 'package:flutter/material.dart';
import 'package:flutter_app/loginPage/loginMainPage.dart';
import 'package:flutter_app/screens/intro_screen.dart';
import 'package:flutter_app/screens/leaderboard_screen.dart';
import 'package:flutter_app/screens/profile_screen.dart';
import 'package:flutter_app/screens/settings_screen.dart';
import 'package:flutter_app/screens/videocam_screen.dart';
import 'package:flutter_app/weather/weather_screen.dart';
import '../screens/profile_screen.dart';

class MenuDrawer extends StatelessWidget {
  const MenuDrawer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
        child: ListView(
      children: buildMenuItems(context),
    ));
  }
}

List<Widget> buildMenuItems(BuildContext context) {
  final List<String> menuTitles = [
    'Profile',
    'Weather',
    'Videocam',
    'Settings'
  ];
  List<Widget> menuItems = [];
  menuItems.add(
    UserAccountsDrawerHeader(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(40.0),
            bottomRight: Radius.circular(40.0),
          ),
          color: Colors.cyan),
      accountName: Text(
        'Coolro',
        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
      ),
      accountEmail: Text('Coolro@naver.com'),
      currentAccountPicture: CircleAvatar(
        backgroundImage: AssetImage('assets/images/Coolro_LoGo1.png'),
      ),
    ),
  );

  for (var element in menuTitles) {
    Widget screen = Container();
    IconData leadingIcon;

    switch (element) {
      case 'Weather':
        leadingIcon = Icons.sunny;
        screen = WeatherScreen();
        break;

      case 'Profile':
        leadingIcon = Icons.person;
        screen = ProfileScreen();
        break;

      case 'Videocam':
        leadingIcon = Icons.videocam;
        screen = VideocamScreen();
        break;

      case 'Settings':
        leadingIcon = Icons.settings;
        screen = SettingsScreen();
        break;

      default:
        leadingIcon = Icons.help; // 기본 아이콘
    }

    menuItems.add(ListTile(
      leading: Icon(leadingIcon),
      title: Text(element, style: const TextStyle(fontSize: 18)),
      onTap: () {
        Navigator.of(context)
            .push(MaterialPageRoute(builder: (context) => screen));
      },
    ));
  }
  return menuItems;
}
