// ignore_for_file: file_names

class DbInfo {
  static const String hostName = '192.168.0.17';
  static const int portNumber = 3306;
  static const String userName = 'test';
  static const String password = 'Ns55904498!';
  static const String dbName = 'test';
}
